import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { View, Text } from 'react-native';

const Tab = createBottomTabNavigator();

export default function MyTabs() {
    return (
        <Tab.Navigator
            initialRouteName='Home'
            screenOptions={{
                tabBarStyle: { backgroundColor: 'black', borderTopColor: 'purple' },
                tabBarActiveTintColor: "purple",
                tabBarInactiveTintColor: "magenta",
            }}>
            <Tab.Screen name="Home" component={Home}
                options={{
                    headerShown: false,
                    tabBarIcon: ({ focused, size, color }) => {
                        if (focused) {
                            return (<Ionicons
                                size={size}
                                color={color}
                                name='home-sharp'
                            />);
                        } return (<Ionicons
                            size={size}
                            color={color}
                            name='home-outline'
                        />)
                    }
                }} />
            <Tab.Screen name="Títulos" component={SettingsScreen}
                options={{
                    headerShown: false,
                    tabBarIcon: ({ focused, size, color }) => {
                        if (focused) {
                            return (<Ionicons
                                size={size}
                                color={color}
                                name='trophy'
                            />);
                        } return (<Ionicons
                            size={size}
                            color={color}
                            name='trophy-outline'
                        />)
                    }
                }} />
        </Tab.Navigator>
    );
}

function Home() {
    return (
        <View>
            <Text>Careca</Text>
        </View>
    )
}

function SettingsScreen() {
    return (
        <View>
            <Text>A</Text>
        </View>
    )
}